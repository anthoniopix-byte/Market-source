import os
from datetime import datetime, timezone

from flask import Flask, jsonify, render_template
from dotenv import load_dotenv

import signal_engine
from data_sources import calendar_client

load_dotenv()

FRED_API_KEY = os.getenv("FRED_API_KEY", "").strip()
FMP_API_KEY = os.getenv("FMP_API_KEY", "").strip()

app = Flask(__name__)

# Contenu statique porté depuis le mindmap "Analyse Fondamentale" et le
# répertoire de sites de référence — inchangé d'une actualisation à l'autre.
INDICATOR_GLOSSARY = [
    {"category": "Politique monétaire", "items": "Taux directeur — ton hawkish (restrictif) ou dovish (accommodant)"},
    {"category": "Inflation", "items": "CPI, Core CPI (hors énergie/alimentation), PCE (indicateur préféré de la Fed)"},
    {"category": "Emploi", "items": "NFP (Non-Farm Payrolls), taux de chômage, salaires horaires moyens"},
    {"category": "Croissance", "items": "PIB (GDP), PMI Manufacturing / Services (ISM)"},
    {"category": "Consommation", "items": "Ventes au détail (Retail Sales), confiance des consommateurs (CB Consumer Confidence)"},
    {"category": "Commerce extérieur", "items": "Balance commerciale"},
]

CENTRAL_BANKS = [
    {"currency": "USD", "bank": "Fed — FOMC, Kevin Warsh (chair depuis mai 2026)"},
    {"currency": "EUR", "bank": "BCE — Christine Lagarde"},
    {"currency": "GBP", "bank": "BOE — Andrew Bailey"},
    {"currency": "JPY", "bank": "BOJ — virage hawkish amorcé depuis 2024"},
    {"currency": "AUD / NZD", "bank": "RBA / RBNZ"},
    {"currency": "CHF", "bank": "SNB"},
]

REFERENCE_LINKS = [
    {"category": "Calendrier économique", "sites": [
        {"name": "Forex Factory", "url": "https://www.forexfactory.com"},
        {"name": "Investing.com — Calendrier éco", "url": "https://www.investing.com/economic-calendar"},
    ]},
    {"category": "Banques centrales", "sites": [
        {"name": "Fed (Réserve Fédérale)", "url": "https://www.federalreserve.gov"},
        {"name": "BCE", "url": "https://www.ecb.europa.eu"},
        {"name": "Bank of England", "url": "https://www.bankofengland.co.uk"},
        {"name": "Bank of Japan", "url": "https://www.boj.or.jp/en"},
        {"name": "CME FedWatch Tool", "url": "https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html"},
    ]},
    {"category": "Positionnement (COT)", "sites": [
        {"name": "CFTC — COT Report", "url": "https://www.cftc.gov/dea/futures/deafut_comb.htm"},
        {"name": "Barchart — COT visualisé", "url": "https://www.barchart.com/forex/commitments-of-traders"},
    ]},
    {"category": "Indices de référence", "sites": [
        {"name": "US Treasury Yields", "url": "https://home.treasury.gov/resource-center/data-chart-center/interest-rates"},
        {"name": "CBOE VIX", "url": "https://www.cboe.com/tradable_products/vix/"},
        {"name": "TradingView (DXY, idées macro)", "url": "https://www.tradingview.com"},
    ]},
    {"category": "News temps réel", "sites": [
        {"name": "Reuters Finance", "url": "https://www.reuters.com/business/finance"},
        {"name": "Bloomberg Markets", "url": "https://www.bloomberg.com/markets"},
    ]},
]

RULES = [
    "Je ne consulte ce tableau qu'une fois par session (pas de rafraîchissement compulsif).",
    "Je ne prends jamais une position à contre-sens d'un biais macro fort (Diff \u2265 |2|).",
    "Si la case DÉCISION FINALE dit ATTENDRE, j'attends — point final, pas de négociation avec moi-même.",
    "Je n'ouvre jamais de position juste avant une annonce à fort impact (NFP, FOMC, CPI).",
    "Si une position est déjà ouverte au moment d'une annonce, j'élargis le stop loss plutôt que de le laisser trop serré.",
    "J'attends la stabilisation du prix après l'annonce avant d'utiliser les confluences techniques (BOS / OB / FVG).",
]


@app.route("/")
def index():
    return render_template(
        "index.html",
        glossary=INDICATOR_GLOSSARY,
        banks=CENTRAL_BANKS,
        links=REFERENCE_LINKS,
        rules=RULES,
        fred_configured=bool(FRED_API_KEY),
        fmp_configured=bool(FMP_API_KEY),
    )


@app.route("/api/refresh")
def api_refresh():
    force_macro = signal_engine.compute_force_macro(FRED_API_KEY)
    news_alerts = calendar_client.fetch_upcoming_events(FMP_API_KEY) if FMP_API_KEY else None
    signal_final = signal_engine.compute_signal_final(force_macro, news_alerts, FRED_API_KEY)

    return jsonify({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "fred_configured": bool(FRED_API_KEY),
        "fmp_configured": bool(FMP_API_KEY),
        "force_macro": force_macro,
        "news_alerts": news_alerts,
        "signal_final": signal_final,
        "criteria_labels": signal_engine.CRITERIA_LABELS,
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5050"))
    app.run(host="127.0.0.1", port=port, debug=False)
