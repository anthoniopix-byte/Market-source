# Terminal Signal Fondamental

Version "app autonome" de `Strategie_Signal_Fondamental.xlsx` : même logique
de décision (Force Macro → Signal Final → Règles anti-surtrading), mais les
cases 1-5 de l'Excel sont maintenant remplies automatiquement par des
sources publiques réelles, avec repli explicite sur "à saisir soi-même"
quand une source n'est pas disponible.

## Ce que l'app fait exactement

- **Force Macro** : calcule un score 1-5 par devise/critère à partir de
  vraies séries économiques (FRED) et du positionnement institutionnel
  (COT Report, CFTC — public, sans clé).
- **Signal Final** : reproduit formule pour formule le fichier Excel
  (`Score Diff`, seuil ±2, `Alerte News < 2h`, `Décision Finale`).
- **Filtre News** : si tu ajoutes une clé Financial Modeling Prep (gratuite),
  le calendrier économique à venir est vérifié automatiquement et déclenche
  "ATTENDRE" comme dans l'Excel.
- **Rappels statiques** : indicateurs clés, banques centrales, liens
  directs, règles anti-surtrading — repris de ton mindmap et de ton
  répertoire de sites.

## Ce que l'app ne fait PAS

- Ce n'est pas un conseiller en investissement : les règles de scoring
  (dans `signal_engine.py`) sont des heuristiques simples et volontairement
  transparentes, pas un modèle validé. Elles sont commentées dans le code
  pour que tu puisses les ajuster à ton propre jugement.
- Certaines cases (ex. taux directeur GBP, croissance GBP/EUR) n'ont pas de
  source gratuite fiable identifiée : elles restent "manuel" — l'app te le
  signale clairement (badge orange) plutôt que d'inventer un chiffre.
- Pas d'exécution d'ordres, pas de connexion MT5 — c'est un outil de
  décision, pas un robot de trading.

## Installation (5 minutes)

```bash
cd fundamental_terminal
pip install -r requirements.txt
cp .env.example .env
```

Ouvre `.env` et colle :
1. **FRED_API_KEY** (obligatoire, gratuite) → https://fred.stlouisfed.org/docs/api/api_key.html
   (inscription en 1 minute, pas de carte bancaire)
2. **FMP_API_KEY** (optionnelle, gratuite, 250 requêtes/jour) → https://site.financialmodelingprep.com
   (active le calendrier économique automatique ; sans elle, tu gardes la
   vérification manuelle sur Forex Factory comme avant)

## Lancer l'app

```bash
python app.py
```

Puis ouvre **http://127.0.0.1:5050** dans ton navigateur. Clique sur
"Actualiser" pour rafraîchir les données (pas d'auto-refresh en boucle,
volontairement — même philosophie anti-surtrading que l'Excel : tu
consultes, tu décides, tu n'y reviens pas).

## Structure du projet

```
fundamental_terminal/
├── app.py                  # serveur Flask + route /api/refresh
├── signal_engine.py         # logique de scoring + Signal Final (à ajuster ici)
├── data_sources/
│   ├── fred_client.py       # FRED (macro US/EUR/GBP)
│   ├── cot_client.py        # CFTC COT Report (positionnement institutionnel)
│   └── calendar_client.py   # Financial Modeling Prep (calendrier éco)
├── templates/index.html
├── static/style.css, app.js
├── .env.example
└── requirements.txt
```

## Sources de données utilisées

| Donnée | Source | Clé requise | Coût |
|---|---|---|---|
| CPI, Core CPI, PCE, NFP, chômage, PIB (USD) | FRED | Oui | Gratuit |
| Taux ECB, CPI/chômage zone euro | FRED | Oui | Gratuit |
| CPI/chômage UK | FRED | Oui | Gratuit |
| VIX, rendements US10Y/US2Y | FRED | Oui | Gratuit |
| Positionnement COT (EUR, GBP, Or, Bitcoin) | CFTC (public) | Non | Gratuit |
| Calendrier économique à venir | Financial Modeling Prep | Optionnelle | Gratuit (250 req/jour) |

## Pour aller plus loin

- Ajuster les seuils de scoring (`trend_score` dans `fred_client.py`) selon
  ta propre sensibilité aux variations macro.
- Ajouter d'autres paires : dupliquer une entrée dans `PAIRS` /
  `BASE_CURRENCY` dans `signal_engine.py`.
- Ce projet est volontairement séparé du gros chantier de plateforme
  (VAHINY) en cours par ailleurs — libre à toi de fusionner plus tard si
  utile, mais il fonctionne aussi en autonome.
