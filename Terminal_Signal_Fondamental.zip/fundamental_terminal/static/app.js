const ASSETS = ["USD", "EUR", "GBP", "XAU", "BTC"];
const CRITERIA_ORDER = ["monetary_policy", "inflation", "employment", "growth", "risk_sentiment"];

const refreshBtn = document.getElementById("refresh-btn");
const lastUpdatedEl = document.getElementById("last-updated");

async function refresh() {
  refreshBtn.disabled = true;
  refreshBtn.textContent = "↻ Actualisation…";
  try {
    const res = await fetch("/api/refresh");
    const data = await res.json();
    renderSignalCards(data.signal_final);
    renderForceTable(data.force_macro, data.criteria_labels);
    renderNews(data.news_alerts, data.fmp_configured);
    const dt = new Date(data.generated_at);
    lastUpdatedEl.textContent = "Dernière actualisation : " + dt.toLocaleString("fr-FR");
  } catch (e) {
    lastUpdatedEl.textContent = "Erreur de connexion au serveur local — vérifie que l'appli tourne bien.";
  } finally {
    refreshBtn.disabled = false;
    refreshBtn.textContent = "↻ Actualiser";
  }
}

function renderSignalCards(rows) {
  const container = document.getElementById("signal-cards");
  container.innerHTML = "";
  rows.forEach(row => {
    const card = document.createElement("div");
    card.className = `signal-card decision-${row.decision}`;

    const diff = row.score_diff;
    const hasDiff = diff !== null && diff !== undefined;
    const clamped = hasDiff ? Math.max(-4, Math.min(4, diff)) : 0;
    const markerPct = ((clamped + 4) / 8) * 100;

    card.innerHTML = `
      <div class="signal-card-head">
        <h4>${row.pair}</h4>
        <span class="decision-tag ${row.decision}">${row.decision}</span>
      </div>
      <div class="barometer"><div class="barometer-marker" style="left:${markerPct}%"></div></div>
      <div class="barometer-scale"><span>VENTE</span><span>Diff ${hasDiff ? diff.toFixed(2) : "—"}</span><span>ACHAT</span></div>
      <p class="signal-card-action">${row.action}</p>
      ${row.cot && row.cot.available
        ? `<div class="signal-card-cot">COT ${row.base} : net ${row.cot.latest_net_pct_oi > 0 ? "+" : ""}${row.cot.latest_net_pct_oi}% de l'OI (au ${row.cot.as_of})</div>`
        : `<div class="signal-card-cot">COT ${row.base} : indisponible</div>`}
    `;
    container.appendChild(card);
  });
}

function renderForceTable(forceMacro, labels) {
  const body = document.getElementById("force-table-body");
  body.innerHTML = "";
  CRITERIA_ORDER.forEach(crit => {
    const tr = document.createElement("tr");
    let html = `<td>${labels[crit] || crit}</td>`;
    ASSETS.forEach(asset => {
      const entry = (forceMacro.scores[asset] || {})[crit] || {};
      const isAuto = (entry.source || "").startsWith("FRED") || (entry.source || "").startsWith("dérivé");
      const scoreText = entry.score !== null && entry.score !== undefined ? entry.score : "—";
      const tagClass = entry.score === null || entry.score === undefined ? "manual" : (isAuto ? "auto" : "manual");
      const tagLabel = entry.score === null || entry.score === undefined ? "manuel" : (isAuto ? "auto" : "manuel");
      html += `<td title="${(entry.detail || "").replace(/"/g, '&quot;')}"><span class="cell-score">${scoreText} <span class="tag ${tagClass}">${tagLabel}</span></span></td>`;
    });
    tr.innerHTML = html;
    body.appendChild(tr);
  });

  ASSETS.forEach(asset => {
    const el = document.getElementById("avg-" + asset);
    if (el) {
      const avg = forceMacro.averages[asset];
      el.textContent = avg !== null && avg !== undefined ? avg.toFixed(2) : "—";
    }
  });
}

function renderNews(events, fmpConfigured) {
  const container = document.getElementById("news-list");
  container.innerHTML = "";
  if (!fmpConfigured) {
    container.innerHTML = `<p class="muted">Clé FMP_API_KEY absente du .env — ajoute-la pour activer le calendrier automatique. En attendant, vérifie manuellement sur Forex Factory avant chaque session.</p>`;
    return;
  }
  if (!events || events.length === 0) {
    container.innerHTML = `<p class="muted">Aucun événement à fort impact dans les prochaines 48h pour USD / EUR / GBP.</p>`;
    return;
  }
  events.forEach(ev => {
    const div = document.createElement("div");
    div.className = "news-item" + (ev.hours_until <= 2 ? " imminent" : "");
    div.innerHTML = `
      <span>${ev.event}</span>
      <span class="currency">${ev.currency}</span>
      <span class="hours">${ev.hours_until <= 0 ? "en cours" : "dans " + ev.hours_until + "h"}</span>
    `;
    container.appendChild(div);
  });
}

refreshBtn.addEventListener("click", refresh);
refresh();
