"""
Client pour le calendrier économique — Financial Modeling Prep (clé gratuite,
250 requêtes/jour). Sans clé, cette fonctionnalité est simplement désactivée
et le Filtre News revient à la saisie manuelle (comme sur l'Excel).
"""
from datetime import datetime, timedelta, timezone
import requests

FMP_URL = "https://financialmodelingprep.com/api/v3/economic_calendar"
TIMEOUT = 15

# Mots-clés utilisés pour repérer les événements réellement structurants
# (NFP, FOMC, CPI, discours de banque centrale, etc. — cf. mindmap fondamental)
HIGH_IMPACT_HINTS = [
    "non farm", "nonfarm", "employment change", "unemployment",
    "interest rate", "fomc", "rate decision", "cpi", "inflation",
    "gdp", "retail sales", "pmi", "ism", "central bank", "press conference",
]


def fetch_upcoming_events(api_key, hours_ahead=48, currencies=("USD", "EUR", "GBP")):
    """
    Retourne les événements à fort impact à venir dans la fenêtre `hours_ahead`,
    triés du plus proche au plus lointain, ou None si la clé est absente ou
    l'appel échoue.
    """
    if not api_key:
        return None
    today = datetime.now(timezone.utc).date()
    params = {
        "from": today.isoformat(),
        "to": (today + timedelta(days=4)).isoformat(),
        "apikey": api_key,
    }
    try:
        r = requests.get(FMP_URL, params=params, timeout=TIMEOUT)
        r.raise_for_status()
        events = r.json()
        if not isinstance(events, list):
            return None
    except requests.RequestException:
        return None
    except ValueError:
        return None

    now = datetime.now(timezone.utc)
    upcoming = []
    for e in events:
        currency = (e.get("currency") or "").upper()
        if currencies and currency not in currencies:
            continue
        impact = (e.get("impact") or "").lower()
        event_name = (e.get("event") or "")
        is_high = impact == "high" or any(h in event_name.lower() for h in HIGH_IMPACT_HINTS)
        if not is_high:
            continue
        try:
            ev_time = datetime.strptime(e.get("date", ""), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        hours_until = (ev_time - now).total_seconds() / 3600
        if hours_until < -1 or hours_until > hours_ahead:
            continue
        upcoming.append({
            "event": event_name,
            "currency": currency,
            "date": e.get("date"),
            "hours_until": round(hours_until, 1),
            "impact": impact or "high",
        })
    upcoming.sort(key=lambda x: x["hours_until"])
    return upcoming
