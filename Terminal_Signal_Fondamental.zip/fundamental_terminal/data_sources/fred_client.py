"""
Client pour l'API FRED (Federal Reserve Bank of St. Louis) — gratuite, clé requise.
Doc : https://fred.stlouisfed.org/docs/api/fred/

Chaque fonction est tolérante aux pannes : en cas d'erreur réseau, de clé
manquante ou de série indisponible, elle retourne None plutôt que de planter,
pour que le reste du tableau de bord continue de fonctionner et bascule
sur la saisie manuelle pour cette seule case.
"""
import requests

FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"
TIMEOUT = 10


def fetch_series(series_id, api_key, limit=36, units=None):
    """Retourne une liste chronologique [(date, valeur_float), ...] ou None."""
    if not api_key or not series_id:
        return None
    params = {
        "series_id": series_id,
        "api_key": api_key,
        "file_type": "json",
        "sort_order": "desc",
        "limit": limit,
    }
    if units:
        params["units"] = units
    try:
        r = requests.get(FRED_BASE, params=params, timeout=TIMEOUT)
        r.raise_for_status()
        payload = r.json()
        obs = []
        for o in payload.get("observations", []):
            v = o.get("value")
            if v in (None, "."):
                continue
            try:
                obs.append((o["date"], float(v)))
            except ValueError:
                continue
        obs.reverse()
        return obs or None
    except requests.RequestException:
        return None
    except (ValueError, KeyError):
        return None


def fetch_first_available(series_candidates, api_key, **kwargs):
    """
    Essaie plusieurs séries candidates dans l'ordre (utile quand l'ID exact
    d'une série internationale est incertain) et retourne la première qui
    répond : (series_id_utilisé, observations) ou (None, None).
    """
    for sid in series_candidates:
        obs = fetch_series(sid, api_key, **kwargs)
        if obs:
            return sid, obs
    return None, None


def trend_score(obs, lookback=3, bullish_if_rising=True):
    """
    Convertit une série d'observations en score 1-5, dans le même esprit que
    la colonne "Force Macro" de l'Excel (1 = très baissier, 5 = très haussier).

    Règle simple et transparente (modifiable) : variation entre la dernière
    valeur et celle d'il y a `lookback` publications.
      variation > +0.5%  -> 5 (ou 1 si bearish_if_rising)
      variation > 0      -> 4 (ou 2)
      quasi stable        -> 3
      variation < 0       -> 2 (ou 4)
      variation < -0.5%  -> 1 (ou 5)
    """
    if not obs or len(obs) < lookback + 1:
        return None
    last = obs[-1][1]
    prev = obs[-1 - lookback][1]
    if prev == 0:
        return None
    change_pct = (last - prev) / abs(prev) * 100

    if change_pct > 0.5:
        score = 5
    elif change_pct > 0.05:
        score = 4
    elif change_pct >= -0.05:
        score = 3
    elif change_pct >= -0.5:
        score = 2
    else:
        score = 1

    if not bullish_if_rising:
        score = 6 - score
    return score, round(change_pct, 3), last
