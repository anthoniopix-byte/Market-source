"""
Client pour le COT Report (CFTC) — API publique Socrata, gratuite, sans clé.
Dataset "Legacy Futures Only" : https://publicreporting.cftc.gov/resource/6dca-aqww.json

Publié chaque vendredi soir avec les données du mardi précédent (3 jours de
retard, comme rappelé dans le mindmap fondamental).
"""
import requests

COT_URL = "https://publicreporting.cftc.gov/resource/6dca-aqww.json"
TIMEOUT = 15

# Nom exact (ou préfixe) du contrat tel qu'il apparaît dans le rapport Legacy
MARKET_NAMES = {
    "EUR": "EURO FX - CHICAGO MERCANTILE EXCHANGE",
    "GBP": "BRITISH POUND STERLING - CHICAGO MERCANTILE EXCHANGE",
    "XAU": "GOLD - COMMODITY EXCHANGE INC.",
    "BTC": "BITCOIN - CHICAGO MERCANTILE EXCHANGE",
    "USD": "USD INDEX - ICE FUTURES U.S.",
}


def fetch_net_positioning(asset_key, weeks=3):
    """
    Retourne les dernières semaines de positionnement net des non-commerciaux
    (large speculators) pour un actif : liste de dicts triée du plus récent
    au plus ancien, ou None si la donnée est indisponible.
    """
    name = MARKET_NAMES.get(asset_key)
    if not name:
        return None
    params = {
        "$where": "upper(market_and_exchange_names) like upper('{}%')".format(name.replace("'", "''")),
        "$order": "report_date_as_yyyy_mm_dd DESC",
        "$limit": weeks,
    }
    try:
        r = requests.get(COT_URL, params=params, timeout=TIMEOUT)
        r.raise_for_status()
        rows = r.json()
        if not rows:
            return None
        results = []
        for row in rows:
            try:
                long_ = float(row.get("noncomm_positions_long_all", 0) or 0)
                short_ = float(row.get("noncomm_positions_short_all", 0) or 0)
                oi = float(row.get("open_interest_all", 0) or 0) or 1
                results.append({
                    "date": row.get("report_date_as_yyyy_mm_dd", "")[:10],
                    "net": long_ - short_,
                    "net_pct_oi": round((long_ - short_) / oi * 100, 2),
                })
            except (TypeError, ValueError):
                continue
        return results or None
    except requests.RequestException:
        return None
    except ValueError:
        return None


def positioning_score(history):
    """
    Traduit le positionnement net + sa variation semaine/semaine en score 1-5,
    même logique que trend_score : net long en expansion = haussier institutionnel.
    """
    if not history or len(history) < 2:
        return None
    latest = history[0]["net_pct_oi"]
    prev = history[1]["net_pct_oi"]
    delta = latest - prev

    if latest > 10 and delta > 0:
        score = 5
    elif latest > 0:
        score = 4
    elif latest == 0:
        score = 3
    elif latest > -10:
        score = 2
    else:
        score = 1
    return score
