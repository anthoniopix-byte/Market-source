"""
Moteur de signal — automatise exactement la logique de
Strategie_Signal_Fondamental.xlsx (onglets "Force Macro" et "Signal Final"),
en remplaçant la saisie manuelle 1-5 par des données réelles quand elles sont
disponibles, avec repli explicite sur "à saisir" sinon.

Règle d'or conservée : jamais de trade à contre-sens d'un biais macro fort
(|Score Diff| >= 2), et toute news à fort impact < 2h force "ATTENDRE".

Les règles ci-dessous sont des heuristiques simples et volontairement
transparentes (pas un modèle propriétaire) : à ajuster librement dans ce
fichier selon ton propre jugement de marché.
"""
from data_sources import fred_client, cot_client

PAIRS = ["EURUSD", "GBPUSD", "XAUUSD", "BTCUSD"]
BASE_CURRENCY = {"EURUSD": "EUR", "GBPUSD": "GBP", "XAUUSD": "XAU", "BTCUSD": "BTC"}
CRITERIA = ["monetary_policy", "inflation", "employment", "growth", "risk_sentiment"]

CRITERIA_LABELS = {
    "monetary_policy": "Politique monétaire",
    "inflation": "Inflation",
    "employment": "Emploi",
    "growth": "Croissance",
    "risk_sentiment": "Sentiment de risque",
}

# ---------------------------------------------------------------------------
# Séries FRED candidates par devise/critère. Plusieurs candidats = tolérance
# aux séries internationales dont l'ID exact peut varier ; la première qui
# répond est utilisée, sinon la case reste "à saisir manuellement".
# ---------------------------------------------------------------------------
FRED_MAP = {
    "USD": {
        "monetary_policy": ["FEDFUNDS"],
        "inflation": ["CPIAUCSL"],
        "employment": ["PAYEMS"],
        "growth": ["GDPC1"],
    },
    "EUR": {
        "monetary_policy": ["ECBDFR"],
        "inflation": ["CP0000EZ19M086NEST", "CPALTT01EZM659N"],
        "employment": ["LRHUTTTTEZM156S"],
        "growth": ["CLVMEURSCAB1GQEA19"],
    },
    "GBP": {
        "monetary_policy": [],  # pas de série FRED fiable identifiée -> manuel
        "inflation": ["GBRCPIALLMINMEI"],
        "employment": ["LRHUTTTTGBM156S"],
        "growth": [],
    },
}

RISK_SENTIMENT_SERIES = ["VIXCLS"]

# Pour XAU et BTC (pas de banque centrale propre) : dérivés du dollar + COT,
# conformément au mindmap ("corrélation inverse au dollar", "sensibilité aux
# taux réels", "réserves des banques centrales" pour l'or).
DERIVED_FROM_USD = {
    "XAU": {"monetary_policy": "inverse", "inflation": "direct", "employment": "inverse", "growth": "inverse"},
    "BTC": {"monetary_policy": "inverse", "inflation": "direct", "employment": "direct", "growth": "direct"},
}

RISK_DIRECTION = {
    # bullish_if_rising : est-ce qu'une hausse du VIX (risk-off) est haussière
    # pour cet actif ?
    "USD": True,   # dollar = valeur refuge modérée
    "EUR": False,
    "GBP": False,
    "XAU": True,   # or = valeur refuge
    "BTC": False,  # actif risqué
}


def score_currency(currency, fred_api_key):
    """
    Retourne {critere: {"score": int|None, "source": str, "detail": str}}
    pour une devise (USD, EUR, GBP) à partir des données FRED réelles.
    """
    result = {}
    candidates_map = FRED_MAP.get(currency, {})
    for crit in ["monetary_policy", "inflation", "employment", "growth"]:
        candidates = candidates_map.get(crit, [])
        if not candidates:
            result[crit] = {"score": None, "source": "manuel", "detail": "Pas de source auto identifiée pour cette devise"}
            continue
        sid, obs = fred_client.fetch_first_available(candidates, fred_api_key)
        if not obs:
            result[crit] = {"score": None, "source": "manuel", "detail": "Source indisponible (clé FRED manquante ou API injoignable)"}
            continue
        scored = fred_client.trend_score(obs, bullish_if_rising=True)
        if not scored:
            result[crit] = {"score": None, "source": "manuel", "detail": "Historique insuffisant"}
            continue
        score, change_pct, last_val = scored
        result[crit] = {
            "score": score,
            "source": f"FRED:{sid}",
            "detail": f"Dernière valeur {last_val:g}, variation {change_pct:+.2f}%",
        }

    # Sentiment de risque (VIX), direction dépendante de l'actif
    sid, obs = fred_client.fetch_first_available(RISK_SENTIMENT_SERIES, fred_api_key)
    if obs:
        scored = fred_client.trend_score(obs, bullish_if_rising=RISK_DIRECTION.get(currency, True))
        if scored:
            score, change_pct, last_val = scored
            result["risk_sentiment"] = {
                "score": score, "source": f"FRED:{sid}",
                "detail": f"VIX {last_val:g}, variation {change_pct:+.2f}%",
            }
        else:
            result["risk_sentiment"] = {"score": None, "source": "manuel", "detail": "Historique VIX insuffisant"}
    else:
        result["risk_sentiment"] = {"score": None, "source": "manuel", "detail": "VIX indisponible (clé FRED manquante)"}

    return result


def score_derived(asset, usd_scores, fred_api_key):
    """Construit les scores XAU/BTC à partir des scores USD + COT (voir DERIVED_FROM_USD)."""
    rules = DERIVED_FROM_USD[asset]
    result = {}
    for crit, mode in rules.items():
        usd_entry = usd_scores.get(crit, {})
        usd_score = usd_entry.get("score")
        if usd_score is None:
            result[crit] = {"score": None, "source": "manuel", "detail": "Dépend du score USD (indisponible)"}
            continue
        score = (6 - usd_score) if mode == "inverse" else usd_score
        result[crit] = {
            "score": score,
            "source": f"dérivé USD ({mode})",
            "detail": f"Basé sur le score USD ({usd_entry.get('source')})",
        }

    # Risk sentiment propre à l'actif
    sid, obs = fred_client.fetch_first_available(RISK_SENTIMENT_SERIES, fred_api_key)
    if obs:
        scored = fred_client.trend_score(obs, bullish_if_rising=RISK_DIRECTION.get(asset, True))
        if scored:
            score, change_pct, last_val = scored
            result["risk_sentiment"] = {"score": score, "source": f"FRED:{sid}", "detail": f"VIX {last_val:g}, variation {change_pct:+.2f}%"}
        else:
            result["risk_sentiment"] = {"score": None, "source": "manuel", "detail": "Historique VIX insuffisant"}
    else:
        result["risk_sentiment"] = {"score": None, "source": "manuel", "detail": "VIX indisponible"}

    return result


def cot_bias(asset_key):
    """Positionnement institutionnel (COT) pour affichage complémentaire — n'entre pas
    dans le score 1-5 (qui reste piloté par les 5 critères macro comme dans l'Excel),
    mais sert de confirmation/contradiction affichée à côté du signal."""
    history = cot_client.fetch_net_positioning(asset_key)
    if not history:
        return {"available": False}
    score = cot_client.positioning_score(history)
    return {
        "available": True,
        "latest_net_pct_oi": history[0]["net_pct_oi"],
        "as_of": history[0]["date"],
        "trend_score": score,
    }


def compute_force_macro(fred_api_key):
    """
    Reproduit l'onglet "Force Macro" : un score par critère et par actif,
    plus le score moyen /5 (équivalent du "Score moyen" de l'Excel).
    """
    usd_scores = score_currency("USD", fred_api_key)
    eur_scores = score_currency("EUR", fred_api_key)
    gbp_scores = score_currency("GBP", fred_api_key)
    xau_scores = score_derived("XAU", usd_scores, fred_api_key)
    btc_scores = score_derived("BTC", usd_scores, fred_api_key)

    all_scores = {"USD": usd_scores, "EUR": eur_scores, "GBP": gbp_scores, "XAU": xau_scores, "BTC": btc_scores}

    averages = {}
    for asset, crit_scores in all_scores.items():
        values = [c["score"] for c in crit_scores.values() if c["score"] is not None]
        averages[asset] = round(sum(values) / len(values), 2) if values else None

    return {"scores": all_scores, "averages": averages}


def compute_signal_final(force_macro, news_alerts, fred_api_key):
    """
    Reproduit l'onglet "Signal Final" ligne par ligne, formule pour formule :
      Score Diff = moyenne(devise base) - moyenne(USD)
      Biais Macro = ACHAT si Diff >= 2, VENTE si Diff <= -2, sinon NEUTRE
      Alerte News <2h = OUI si un event à fort impact tombe dans les 2h pour
                         une des deux devises de la paire
      Décision Finale = ATTENDRE si alerte news, sinon Biais Macro
    """
    averages = force_macro["averages"]
    usd_avg = averages.get("USD")
    rows = []
    alert_currencies = set()
    if news_alerts:
        for ev in news_alerts:
            if ev["hours_until"] <= 2:
                alert_currencies.add(ev["currency"])

    for pair in PAIRS:
        base = BASE_CURRENCY[pair]
        base_avg = averages.get(base)
        cot = cot_bias(base)

        if base_avg is None or usd_avg is None:
            score_diff = None
            biais = "DONNÉES INCOMPLÈTES"
        else:
            score_diff = round(base_avg - usd_avg, 2)
            if score_diff >= 2:
                biais = "ACHAT"
            elif score_diff <= -2:
                biais = "VENTE"
            else:
                biais = "NEUTRE"

        pair_currencies = {"USD", base} if base != "XAU" and base != "BTC" else {"USD"}
        news_flag = bool(pair_currencies & alert_currencies) if alert_currencies else False

        if news_flag:
            decision = "ATTENDRE"
        else:
            decision = biais

        if decision == "ATTENDRE":
            action = "News à fort impact imminente (<2h) — ne pas ouvrir de position"
        elif decision == "NEUTRE":
            action = "Pas de biais fort - rester à l'écart ou attendre confirmation technique"
        elif decision == "DONNÉES INCOMPLÈTES":
            action = "Compléter les cases manuelles (voir badges 'manuel') avant de trancher"
        else:
            action = f"Biais macro confirmé ({decision}) - chercher confluence technique (BOS / OB / FVG) dans ce sens"

        rows.append({
            "pair": pair, "base": base, "score_diff": score_diff, "biais": biais,
            "news_flag": news_flag, "decision": decision, "action": action,
            "cot": cot,
        })
    return rows
